# Beta implementation and release plan

## Goal and scope

Keep SADP discovery available while disabling SADP activation. When SADP
activation is selected, inform the operator and use ISAPI only when the target
address, route and operation capability are established. Never change host
network settings automatically.

Implement the ISAPI operations described in the specifications, including
known-address discovery, authentication, activation, verification, network
configuration, user management, security questions and documented terminal
management. Device-specific, unverified procedures must fail explicitly.
Retain SADP network configuration only for profiles actually verified on the
target device; the observed salted/AES profile is not yet established.

## Work items

1. **Specification and inventory:** reconcile English and Russian system,
   route, UI, procedure and help documents. Define operation inputs, capability
   and identity checks, failure outcomes, strategy and CLI compatibility,
   confirmation, security and per-device results.
2. **SADP activation gate:** enforce the ban at the service and routing
   boundaries, not only in the UI. Show a localized message and attempt ISAPI
   only when prerequisites are met. Preserve SADP discovery and verified
   network profiles; reject unverified profiles before sending a mutation.
3. **ISAPI transport and authentication:** use each target's actual address,
   bounded and cancellable HTTP(S), safe TLS policy, Digest authentication and
   explicitly enabled Basic only. Classify HTTP and ISAPI errors and never log
   credentials or sensitive payloads.
4. **ISAPI operations:** complete the documented activation challenge and
   encryption, verify activated state and authenticated device identity, and
   implement DHCP/static network changes with reappearance and identity
   verification. Implement capability-gated encrypted user, recovery-question
   and terminal-management procedures where their device-specific schema and
   key source are established; otherwise fail explicitly.
5. **Application integration:** connect discovery, target resolution,
   credentials, protocol selection and per-device outcomes to CLI and TUI.
   Maintain cancellation, confirmation, bounded concurrency and localization.
6. **Verification:** add synthetic protocol and integration tests covering
   positive and negative paths, authentication, encryption, response status,
   identity, cancellation, multi-device isolation and secret redaction. Run
   `go test ./...`, `go test -race ./...`, `go vet ./...`, `go build ./...`
   and applicable documentation checks.
7. **Real-device acceptance:** test the claimed operations on real devices,
   record model and firmware compatibility, and verify Windows 10/11 and
   Ubuntu x64. A reachable ISAPI address is required; discovery alone does
   not establish HTTP reachability.
8. **Release:** after all acceptance gates pass, build Windows and Linux x64
   artifacts; do not build a macOS artifact. Verify packaged configuration and localization, publish
   SHA-256 checksums, release notes and compatibility matrix, and create a
   prerelease in the CDSRaBot repository.

## Release decisions and constraints

- The user selected an unsigned beta. Publication must include explicit
  unsigned-artifact warnings; this decision does not waive acceptance gates.
- Do not publish a beta or claim interoperability without real-device
  acceptance. List unverified models and features as unsupported.
- Research captures and local SDK logs can contain credentials and must never
  be included in commits, fixtures, logs or release artifacts.
- Record compatibility results without passwords, keys, nonces, ciphertext or
  credential-bearing XML. Use synthetic values in automated tests.

## Current implementation status

- SADP activation is blocked in the UI workflow and route selector. The
  executable still reports activation unavailable; it does not yet invoke the
  ISAPI replacement. TUI and REPL show the disabled message before requiring a
  target, confirmation or password. A separate one-shot ISAPI activation path
  is wired but fails closed because the executable has no trusted profile.
- SADP discovery is available through the TUI session and bounded CLI
  snapshots. CLI snapshots combine repeated advertisements by MAC and sender
  address and report discovery errors alongside any partial results.
- ISAPI includes bounded HTTP transport, Digest authentication and opt-in
  Basic over HTTPS, target-specific
  addressing, authenticated known-address discovery and an activation
  identity-verification component. The one-shot activation path is covered
  end-to-end using synthetic gate and device responses, including uncertain
  delivery and authenticated identity failure. The activation challenge uses the
  captured `PublicKey` envelope and rejects ambiguous challenge and status
  fields; passwords are validated before any request to prevent truncation.
  A read-only activation-state preflight distinguishes active and inactive
  states; it does not authenticate a device or authorize mutation.
  The encrypted activation component additionally requires a trusted
  device-specific identity/profile gate and records an attempted PUT even if
  its result is unknown. No production gate has been established.
  Generic user-field encryption, the captured session-login proof and
  security-question field-encryption/KDF format are available for confirmed
  schemas. A one-shot user create/update path is wired behind an injected
  capability/schema/key profile and has synthetic end-to-end tests, but no
  production profile exists. Recovery-question encryption is not wired to an
  endpoint. These components are not yet verified on physical devices.
- Read-only authenticated ISAPI discovery by explicit IP and MAC is wired to
  the one-shot CLI. It requires redirected password input, checks reachability
  and matching identity, and has not been tested on physical devices.
- Read-only activation-state preflight is available in the one-shot CLI, TUI
  console and REPL; its result explicitly marks device identity as unverified.
- Read-only TerminalMgr discovery settings are available through the
  authenticated one-shot `isapi-terminal` command with an explicit MAC and
  terminal ID. Only documented fields actually returned by the device are
  reported. Capability parsing and configuration writes remain unimplemented;
  physical compatibility is unverified.
- ISAPI network has a one-shot path covered by synthetic static and DHCP
  tests, including authenticated identity/profile gating, uncertain PUT
  outcomes and restart reporting. The executable refuses it before password
  or network access because no verified device-specific profile is installed.
  Automatic reboot is not implemented. Static-address and SADP-assisted DHCP reappearance locators
  authenticate the candidate's ISAPI identity, but have not been validated
  on physical devices. Explicit interface binding, production user and
  terminal management, interactive UI credential input, bulk workflows and
  release acceptance also remain to be implemented and validated.
- A beta release requires real-device testing on the supported models and
  firmware, native platform acceptance, and the signing decision above.
- The user authorized only read-only discovery and display of device
  information and activation state on a DS-2CD2643G2-LIZS2. A Windows 11 SADP
  session received unauthenticated matching-MAC advertisements identifying
  `DS-2CD2643G2-LIZS2U`, firmware `V5.7.23build 260320`, and reporting an
  active state. The one-shot CLI successfully returned model, serial number,
  MAC, IP and activation state with the bundled 65507-byte SADP datagram
  limit. The previous bundled 1500-byte setting encountered an oversized
  datagram in this network; the omitted/zero-value default remains 1500.
  A read-only activation-status request to the
  advertised address timed out; the host and advertised address were on
  different subnets. This is not authenticated identity verification or
  evidence of ISAPI compatibility. Further network, user, activation,
  recovery, and terminal mutations are not authorized. Ubuntu acceptance
  remains open.
- Validation of commit `c01dd8b` passed the full Go test suite and the full
  race-enabled suite on Windows. A Linux amd64 executable was also built and
  its `version` command ran under Kali Linux on WSL. This smoke test is not
  Ubuntu acceptance and does not establish device compatibility.
- The `cmd/package-beta` tool can build local, unsigned, explicitly unverified
  candidate archives and SHA-256 checksums. This is packaging preparation,
  not release approval or publication.
